<!DOCTYPE html>
<?php
ini_set('display_errors', '0');
?>
<?php
session_start();
require_once 'connect_him.php';
$ID = $_SESSION['userid'];
?>
<html>
<head>
    <title>record Info.</title>
    <style>
    *{
        margin:0;
        padding: 0;
        box-sizing: border-box;
    }
    html{
        height: 100%;
    }
    body{
        font-family:'Open Sans', Arial, sans-serif;
        font-size: 1rem;
        line-height: 1.6;
        height: 100%;
    }
    .wrap {
        width: 100%;
        height: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        background: #fafafa;
    }
    .login-form{
        width: 350px;
        margin: 0 auto;
        border: 1px solid #ddd;
        padding: 2rem;
        background: #ffffff;
    }
    .form-input{
        background: #fafafa;
        border: 1px solid #eeeeee;
        padding: 12px;
        width: 100%;
    }
    .form-group{
        margin-bottom: 1rem;
    }
    .form-button{
        background: #68a4c4;
        border: 1px solid #ddd;
        color: #ffffff;
        padding: 10px;
        width: 100%;
        text-transform: uppercase;
    }
    .form-button:hover{
        background: #69c8e7;
    }
    .form-header{
        text-align: center;
        margin-bottom : 2rem;
    }
    .form-footer{
        text-align: center;
    }
    a{
        font-family: 'Open Sans', Arial, sans-serif;
        color: #ffffff;
        text-decoration:none;
    } 
    </style>
</head>
<body>
    <div class="wrap">
	<form method = 'post' action = 'DBadmin.php'>
            <div class="form-header">
                <h3>Administartion</h3>
            </div>
			<?php
			$Pid = $_POST['info'];
			
			if ($Pid)
			{
				echo "
				<div class=\"form-group\">
					<input type=\"text\" class=\"form-input\" placeholder=\"Blood Pressure\" name=\"blood\">
				</div>
				<div class=\"form-group\">
					<input type=\"text\" class=\"form-input\" placeholder=\"Cholesterol\" name=\"Cholesterol\">
				</div>
				<div class=\"form-group\">
					<input type=\"text\" class=\"form-input\" placeholder=\"Blood Sugar\" name=\"sugar\">
				</div>
				
				<div class=\"form-group\">
					<input type=\"text\" class=\"form-input\" placeholder=\"Drug in Use\" name=\"drug\">
				</div>
				<div class=\"form-group\">
					<input type=\"text\" class=\"form-input\" placeholder=\"Vaccination\" name=\"Vac\">
				</div>
				<div class=\"form-group\">
					<input type=\"text\" class=\"form-input\" placeholder=\"Medical Device\" name=\"device\">
				</div>
				<div class=\"form-group\">
					<input type=\"text\" class=\"form-input\" placeholder=\"Allergies\" name=\"Allergies\">
				</div>
				<div class=\"form-group\">
					<input type=\"text\" class=\"form-input\" placeholder=\"Diseases\" name=\"diseases\">
				</div>
				<div class=\"form-group\">
					<button class=\"form-button\" type=\"submit\" name=\"subbut\" value=\"$Pid\">SUBMIT</button>
				</div>";
			}
            
			?>
        </form>
    </div><!--/.wrap-->
</body>
</html>