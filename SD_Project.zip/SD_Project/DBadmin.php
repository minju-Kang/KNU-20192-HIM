<?php
ini_set('display_errors', '0');
?>
<?php
 session_start();
 require_once 'connect_him.php';
	$ID = $_SESSION['userid'];
	$Pid = $_POST['subbut'];
	if ($Pid)
	{
			$blood=$_POST['blood'];
			$chol=$_POST['Cholesterol'];
			$sugar= $_POST['sugar'];
			$drug = $_POST['drug'];
			$vac=$_POST['Vac'];
			$device=$_POST['device'];
			$allergies=$_POST['Allergies'];
			$disease=$_POST['diseases'];
			
			$sql = "UPDATE profile SET Blood_Pressure='$blood', Cholesterol='$chol', Blood_Sugar='$sugar' WHERE Id='$Pid'";
			$sql2 = "UPDATE currhealth SET Drugs_in_use='$drug', Vaccination='$vac', Medical_Device='$device', Allergies='$allergies', Diseases='$disease' WHERE Id='$Pid'";

			if($link->query($sql) && $link->query($sql2)){
			?>      
			<script>
							alert("Modify Success!");document.location.href='D_login.html';
			</script>
			<?php
			}
			else{
			?>
			<script>
							alert("Fail");document.location.href='D_login.html';
			</script>

			<?php
			}
	}
	 ?>

