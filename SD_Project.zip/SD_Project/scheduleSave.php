<?php
ini_set('display_errors', '0');
?>
<?php               
	require_once 'connect_him.php';
	
	session_start();
	
	$ID = $_SESSION['userid'];
	$Year = $_POST['FirstSelectYear'];
	$Month = $_POST['FirstSelectMonth'];
	$Date = $_POST['FirstSelectDay'];
	$Content = $_POST['content'];
	
	$sql = "insert into SCHEDULE values('$ID', $Year, $Month, $Date, '$Content')";
	
	if(mysqli_query($link, $sql)) {
    echo "success inserting";
  } else {
    echo "fail to insert sql";
  }
  
  echo "<script> alert('schedule saved'); </script>";
  
$sql2 = "select * from patient_info where Id='$ID'";
$result = mysqli_query($link, $sql2);
if (mysqli_num_rows($result)>0)
{
  echo "<script> document.location.href = 'P_schedule.html'; </script>";
}
else
{
echo "<script> document.location.href = 'D_schedule.html'; </script>";
}
?>